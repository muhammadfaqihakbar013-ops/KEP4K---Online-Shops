import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import ProductCard from "./ProductCard";
import { Zap } from "lucide-react";

interface Product {
  id: string;
  name: string;
  price: number;
  original_price: number | null;
  image_url: string | null;
  stock: number;
  discount_percent: number | null;
  is_flash_sale: boolean | null;
}

const FlashSale = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [timeLeft, setTimeLeft] = useState({
    hours: 5,
    minutes: 30,
    seconds: 45,
  });

  useEffect(() => {
    const fetchFlashSaleProducts = async () => {
      const { data } = await supabase
        .from("products")
        .select("*")
        .eq("is_flash_sale", true)
        .limit(6);
      if (data) setProducts(data);
    };
    fetchFlashSaleProducts();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        let { hours, minutes, seconds } = prev;
        
        if (seconds > 0) {
          seconds--;
        } else if (minutes > 0) {
          minutes--;
          seconds = 59;
        } else if (hours > 0) {
          hours--;
          minutes = 59;
          seconds = 59;
        } else {
          // Reset timer
          hours = 5;
          minutes = 30;
          seconds = 45;
        }
        
        return { hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-8 bg-gradient-to-b from-secondary/50 to-background">
      <div className="container">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Zap className="h-8 w-8 text-primary fill-primary animate-pulse" />
              <h2 className="text-2xl md:text-3xl font-bold">
                <span className="text-gradient-gold">FLASH</span>
                <span className="text-foreground"> SALE</span>
              </h2>
            </div>
            
            {/* Countdown Timer */}
            <div className="flex items-center gap-1">
              <div className="bg-primary text-primary-foreground px-2 py-1 rounded font-mono text-lg font-bold min-w-[40px] text-center animate-countdown">
                {String(timeLeft.hours).padStart(2, "0")}
              </div>
              <span className="text-primary font-bold">:</span>
              <div className="bg-primary text-primary-foreground px-2 py-1 rounded font-mono text-lg font-bold min-w-[40px] text-center animate-countdown">
                {String(timeLeft.minutes).padStart(2, "0")}
              </div>
              <span className="text-primary font-bold">:</span>
              <div className="bg-primary text-primary-foreground px-2 py-1 rounded font-mono text-lg font-bold min-w-[40px] text-center animate-countdown">
                {String(timeLeft.seconds).padStart(2, "0")}
              </div>
            </div>
          </div>
          
          <button className="text-primary hover:text-accent transition-colors font-medium">
            Lihat Semua &rarr;
          </button>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {products.map((product, index) => (
            <div
              key={product.id}
              className="animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <ProductCard product={product} showFlashBadge />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FlashSale;
