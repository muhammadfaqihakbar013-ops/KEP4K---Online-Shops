import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, ShoppingCart, User, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { useCart } from "@/hooks/useCart";

const Header = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, signOut } = useAuth();
  const { cartCount } = useCart();
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      {/* Top Bar */}
      <div className="border-b border-border bg-secondary/50">
        <div className="container flex h-8 items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center gap-4">
            <span>Seller Centre</span>
            <span className="hidden sm:inline">|</span>
            <span className="hidden sm:inline">Download App</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="hidden sm:inline">Bantuan</span>
            {user ? (
              <button onClick={signOut} className="hover:text-primary transition-colors">
                Logout
              </button>
            ) : (
              <>
                <Link to="/auth" className="hover:text-primary transition-colors">
                  Daftar
                </Link>
                <span>|</span>
                <Link to="/auth" className="hover:text-primary transition-colors">
                  Login
                </Link>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container py-4">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <div className="w-10 h-10 bg-gradient-gold rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">K</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-xl font-bold text-gradient-gold">KEP4K</h1>
              <p className="text-[10px] text-muted-foreground -mt-1">Online Shop</p>
            </div>
          </Link>

          {/* Search Bar - Desktop */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-2xl">
            <div className="relative w-full">
              <Input
                type="text"
                placeholder="Cari produk premium..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-12"
              />
              <Button
                type="submit"
                size="icon"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-10 w-10"
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </form>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Cart */}
            <Link to="/cart">
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-primary text-[10px] font-bold text-primary-foreground flex items-center justify-center animate-pulse-gold">
                    {cartCount}
                  </span>
                )}
              </Button>
            </Link>

            {/* User */}
            {user ? (
              <Link to="/profile">
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                </Button>
              </Link>
            ) : (
              <Link to="/auth" className="hidden sm:block">
                <Button variant="gold-outline" size="sm">
                  Login
                </Button>
              </Link>
            )}

            {/* Mobile Menu Toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Search */}
        <form onSubmit={handleSearch} className="mt-4 md:hidden">
          <div className="relative">
            <Input
              type="text"
              placeholder="Cari produk premium..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-12"
            />
            <Button
              type="submit"
              size="icon"
              className="absolute right-1 top-1/2 -translate-y-1/2 h-10 w-10"
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </form>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <nav className="mt-4 md:hidden animate-fade-in">
            <div className="flex flex-col gap-2 p-4 bg-secondary rounded-lg">
              <Link to="/" className="py-2 hover:text-primary transition-colors">
                Beranda
              </Link>
              <Link to="/cart" className="py-2 hover:text-primary transition-colors">
                Keranjang ({cartCount})
              </Link>
              {user ? (
                <>
                  <Link to="/orders" className="py-2 hover:text-primary transition-colors">
                    Pesanan Saya
                  </Link>
                  <button onClick={signOut} className="py-2 text-left hover:text-primary transition-colors">
                    Logout
                  </button>
                </>
              ) : (
                <Link to="/auth" className="py-2 hover:text-primary transition-colors">
                  Login / Daftar
                </Link>
              )}
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;
