import { Button } from "@/components/ui/button";
import { ArrowRight, Crown } from "lucide-react";
import { Link } from "react-router-dom";

const HeroBanner = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-background via-secondary to-background py-16 md:py-24">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
      </div>

      <div className="container relative">
        <div className="max-w-3xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6 animate-fade-in">
            <Crown className="h-4 w-4 text-primary" />
            <span className="text-sm text-primary font-medium">Premium Quality Products</span>
          </div>

          {/* Heading */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 animate-fade-in" style={{ animationDelay: "100ms" }}>
            <span className="text-gradient-gold">KEP4K</span>
            <br />
            <span className="text-foreground">Online Shop</span>
          </h1>

          {/* Subtitle */}
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-xl mx-auto animate-fade-in" style={{ animationDelay: "200ms" }}>
            Temukan koleksi produk premium dengan harga terbaik. Kualitas terjamin, pengiriman cepat.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in" style={{ animationDelay: "300ms" }}>
            <Button size="xl" className="gap-2 group">
              Mulai Belanja
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </Button>
            <Link to="/auth">
              <Button size="xl" variant="gold-outline">
                Daftar Sekarang
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 mt-16 animate-fade-in" style={{ animationDelay: "400ms" }}>
            <div>
              <p className="text-3xl md:text-4xl font-bold text-gradient-gold">10K+</p>
              <p className="text-sm text-muted-foreground mt-1">Produk</p>
            </div>
            <div>
              <p className="text-3xl md:text-4xl font-bold text-gradient-gold">50K+</p>
              <p className="text-sm text-muted-foreground mt-1">Pelanggan</p>
            </div>
            <div>
              <p className="text-3xl md:text-4xl font-bold text-gradient-gold">99%</p>
              <p className="text-sm text-muted-foreground mt-1">Kepuasan</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroBanner;
