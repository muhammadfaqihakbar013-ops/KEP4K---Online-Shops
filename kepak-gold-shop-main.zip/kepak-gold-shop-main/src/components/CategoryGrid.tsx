import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { 
  Smartphone, 
  Shirt, 
  Watch, 
  Heart, 
  Dumbbell, 
  Car, 
  Gamepad2,
  ShoppingBag
} from "lucide-react";

interface Category {
  id: string;
  name: string;
  icon: string;
  slug: string;
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Smartphone,
  Shirt,
  Dress: ShoppingBag,
  Watch,
  Heart,
  Dumbbell,
  Car,
  Gamepad2,
};

const CategoryGrid = () => {
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase.from("categories").select("*");
      if (data) setCategories(data);
    };
    fetchCategories();
  }, []);

  return (
    <section className="py-8">
      <div className="container">
        <h2 className="text-2xl font-bold mb-6 text-gradient-gold">Kategori</h2>
        <div className="grid grid-cols-4 md:grid-cols-8 gap-4">
          {categories.map((category, index) => {
            const IconComponent = iconMap[category.icon] || ShoppingBag;
            return (
              <button
                key={category.id}
                className="flex flex-col items-center gap-3 p-4 rounded-xl bg-secondary hover:bg-muted transition-all duration-300 hover-lift group"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="w-12 h-12 rounded-full bg-gradient-gold flex items-center justify-center group-hover:shadow-gold transition-all duration-300">
                  <IconComponent className="h-6 w-6 text-primary-foreground" />
                </div>
                <span className="text-xs text-center text-foreground/80 group-hover:text-primary transition-colors">
                  {category.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default CategoryGrid;
