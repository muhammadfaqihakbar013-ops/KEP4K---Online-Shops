import { ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useCart } from "@/hooks/useCart";

interface Product {
  id: string;
  name: string;
  price: number;
  original_price: number | null;
  image_url: string | null;
  stock: number;
  discount_percent: number | null;
}

interface ProductCardProps {
  product: Product;
  showFlashBadge?: boolean;
}

const formatPrice = (price: number) => {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(price);
};

const ProductCard = ({ product, showFlashBadge = false }: ProductCardProps) => {
  const { addToCart } = useCart();

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    await addToCart(product.id);
  };

  return (
    <Card className="group overflow-hidden hover-lift cursor-pointer">
      <div className="relative aspect-square overflow-hidden bg-muted">
        <img
          src={product.image_url || "https://placehold.co/400x400/1a1a1a/d4af37?text=KEP4K"}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        
        {/* Discount Badge */}
        {product.discount_percent && product.discount_percent > 0 && (
          <div className="absolute top-2 left-2 bg-destructive text-destructive-foreground text-xs font-bold px-2 py-1 rounded">
            -{product.discount_percent}%
          </div>
        )}

        {/* Flash Sale Badge */}
        {showFlashBadge && (
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-gold text-primary-foreground text-xs font-bold py-1 text-center">
            STOK TERBATAS
          </div>
        )}

        {/* Quick Add Button */}
        <Button
          size="icon"
          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0"
          onClick={handleAddToCart}
        >
          <ShoppingCart className="h-4 w-4" />
        </Button>
      </div>

      <div className="p-4">
        <h3 className="text-sm font-medium line-clamp-2 mb-2 group-hover:text-primary transition-colors">
          {product.name}
        </h3>
        
        <div className="space-y-1">
          <p className="text-lg font-bold text-primary">
            {formatPrice(product.price)}
          </p>
          
          {product.original_price && product.original_price > product.price && (
            <p className="text-xs text-muted-foreground line-through">
              {formatPrice(product.original_price)}
            </p>
          )}
        </div>

        {/* Stock indicator */}
        {product.stock < 10 && product.stock > 0 && (
          <p className="text-xs text-destructive mt-2">
            Sisa {product.stock} unit
          </p>
        )}
      </div>
    </Card>
  );
};

export default ProductCard;
