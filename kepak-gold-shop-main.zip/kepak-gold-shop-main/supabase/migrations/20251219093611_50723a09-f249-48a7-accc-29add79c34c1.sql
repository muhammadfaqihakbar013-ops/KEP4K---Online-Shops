-- Create profiles table for user data
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  phone TEXT,
  address TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own profile" ON public.profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);

-- Trigger for new user profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, full_name)
  VALUES (new.id, new.raw_user_meta_data ->> 'full_name');
  RETURN new;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Categories table
CREATE TABLE public.categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  icon TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view categories" ON public.categories FOR SELECT USING (true);

-- Products table
CREATE TABLE public.products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(12,2) NOT NULL,
  original_price DECIMAL(12,2),
  image_url TEXT,
  category_id UUID REFERENCES public.categories(id),
  stock INTEGER NOT NULL DEFAULT 0,
  is_flash_sale BOOLEAN DEFAULT false,
  discount_percent INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view products" ON public.products FOR SELECT USING (true);

-- Cart table
CREATE TABLE public.cart_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  quantity INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, product_id)
);

ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own cart" ON public.cart_items FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can add to their own cart" ON public.cart_items FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own cart" ON public.cart_items FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete from their own cart" ON public.cart_items FOR DELETE USING (auth.uid() = user_id);

-- Orders table
CREATE TABLE public.orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  total_amount DECIMAL(12,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  shipping_address TEXT NOT NULL,
  phone TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own orders" ON public.orders FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own orders" ON public.orders FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Order items table
CREATE TABLE public.order_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id),
  quantity INTEGER NOT NULL,
  price DECIMAL(12,2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own order items" ON public.order_items FOR SELECT 
  USING (EXISTS (SELECT 1 FROM public.orders WHERE orders.id = order_items.order_id AND orders.user_id = auth.uid()));
CREATE POLICY "Users can create their own order items" ON public.order_items FOR INSERT 
  WITH CHECK (EXISTS (SELECT 1 FROM public.orders WHERE orders.id = order_items.order_id AND orders.user_id = auth.uid()));

-- Insert sample categories
INSERT INTO public.categories (name, icon, slug) VALUES
('Elektronik', 'Smartphone', 'elektronik'),
('Fashion Pria', 'Shirt', 'fashion-pria'),
('Fashion Wanita', 'Dress', 'fashion-wanita'),
('Aksesoris', 'Watch', 'aksesoris'),
('Kesehatan', 'Heart', 'kesehatan'),
('Olahraga', 'Dumbbell', 'olahraga'),
('Otomotif', 'Car', 'otomotif'),
('Hobi', 'Gamepad2', 'hobi');

-- Insert sample products
INSERT INTO public.products (name, description, price, original_price, image_url, category_id, stock, is_flash_sale, discount_percent) VALUES
('iPhone 15 Pro Max', 'Smartphone flagship Apple dengan chip A17 Pro', 21999000, 24999000, 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400', (SELECT id FROM public.categories WHERE slug = 'elektronik'), 50, true, 12),
('Samsung Galaxy S24 Ultra', 'Smartphone Android premium dengan S Pen', 18999000, 21999000, 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=400', (SELECT id FROM public.categories WHERE slug = 'elektronik'), 30, true, 14),
('MacBook Pro M3', 'Laptop powerful untuk professional', 35999000, 39999000, 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400', (SELECT id FROM public.categories WHERE slug = 'elektronik'), 20, true, 10),
('Kemeja Batik Premium', 'Kemeja batik tulis asli Solo', 899000, 1299000, 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400', (SELECT id FROM public.categories WHERE slug = 'fashion-pria'), 100, true, 31),
('Sneakers Nike Air Max', 'Sepatu casual untuk sehari-hari', 2499000, 2999000, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400', (SELECT id FROM public.categories WHERE slug = 'fashion-pria'), 75, true, 17),
('Jam Tangan Rolex Submariner', 'Jam tangan mewah klasik', 185000000, 199000000, 'https://images.unsplash.com/photo-1587836374828-a7b3b2b12b04?w=400', (SELECT id FROM public.categories WHERE slug = 'aksesoris'), 5, false, 7),
('Dress Elegan Satin', 'Gaun pesta elegan untuk wanita', 1599000, 1999000, 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400', (SELECT id FROM public.categories WHERE slug = 'fashion-wanita'), 40, true, 20),
('AirPods Pro 2', 'Earbuds wireless dengan ANC', 3899000, 4299000, 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=400', (SELECT id FROM public.categories WHERE slug = 'elektronik'), 60, true, 9),
('Vitamin C 1000mg', 'Suplemen kesehatan daya tahan tubuh', 149000, 199000, 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400', (SELECT id FROM public.categories WHERE slug = 'kesehatan'), 200, false, 25),
('Dumbbell Set 20kg', 'Set barbel untuk latihan di rumah', 599000, 799000, 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400', (SELECT id FROM public.categories WHERE slug = 'olahraga'), 30, true, 25),
('PS5 Console', 'Konsol gaming next-gen Sony', 8499000, 9999000, 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400', (SELECT id FROM public.categories WHERE slug = 'hobi'), 15, true, 15),
('Helm Full Face AGV', 'Helm premium untuk keselamatan berkendara', 4299000, 4999000, 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400', (SELECT id FROM public.categories WHERE slug = 'otomotif'), 25, false, 14);

-- Function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();